<?php
echo file_get_contents('file_get_contents_sample.txt');
?>